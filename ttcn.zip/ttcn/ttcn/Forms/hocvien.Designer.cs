﻿namespace ttcn
{
    partial class hocvien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grtimkiemhv = new System.Windows.Forms.GroupBox();
            this.cbomonhoc = new System.Windows.Forms.ComboBox();
            this.btnlamlai = new System.Windows.Forms.Button();
            this.btntimkiem = new System.Windows.Forms.Button();
            this.lbngaybd = new System.Windows.Forms.Label();
            this.lbten = new System.Windows.Forms.Label();
            this.lbma = new System.Windows.Forms.Label();
            this.rdoalto = new System.Windows.Forms.RadioButton();
            this.chktimtheolop = new System.Windows.Forms.CheckBox();
            this.rdotenor = new System.Windows.Forms.RadioButton();
            this.rdobaritone = new System.Windows.Forms.RadioButton();
            this.rdobass = new System.Windows.Forms.RadioButton();
            this.rdosoprano = new System.Windows.Forms.RadioButton();
            this.rdocap3 = new System.Windows.Forms.RadioButton();
            this.rdocap2 = new System.Windows.Forms.RadioButton();
            this.rdocap1 = new System.Windows.Forms.RadioButton();
            this.txttenhocvien = new System.Windows.Forms.TextBox();
            this.txtmahocvien = new System.Windows.Forms.TextBox();
            this.chktimtheoloaigiong = new System.Windows.Forms.CheckBox();
            this.chktimtheocapdo = new System.Windows.Forms.CheckBox();
            this.chktimtenhocvien = new System.Windows.Forms.CheckBox();
            this.chktimmahocvien = new System.Windows.Forms.CheckBox();
            this.btnthem = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btnsua = new System.Windows.Forms.Button();
            this.dataGridViewhocvien = new System.Windows.Forms.DataGridView();
            this.btnxemall = new System.Windows.Forms.Button();
            this.grdieuchinhhv = new System.Windows.Forms.GroupBox();
            this.txtdiachi = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.mskngaysinh = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.msksdt = new System.Windows.Forms.MaskedTextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cbothongtincapdo = new System.Windows.Forms.ComboBox();
            this.cbothongtinloaigiong = new System.Windows.Forms.ComboBox();
            this.btnboqua = new System.Windows.Forms.Button();
            this.btnluu = new System.Windows.Forms.Button();
            this.chkgtnu = new System.Windows.Forms.CheckBox();
            this.chkgtnam = new System.Windows.Forms.CheckBox();
            this.txtthongtintenhv = new System.Windows.Forms.TextBox();
            this.txtthongtinmahv = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grtimkiemhv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewhocvien)).BeginInit();
            this.grdieuchinhhv.SuspendLayout();
            this.SuspendLayout();
            // 
            // grtimkiemhv
            // 
            this.grtimkiemhv.Controls.Add(this.cbomonhoc);
            this.grtimkiemhv.Controls.Add(this.btnlamlai);
            this.grtimkiemhv.Controls.Add(this.btntimkiem);
            this.grtimkiemhv.Controls.Add(this.lbngaybd);
            this.grtimkiemhv.Controls.Add(this.lbten);
            this.grtimkiemhv.Controls.Add(this.lbma);
            this.grtimkiemhv.Controls.Add(this.rdoalto);
            this.grtimkiemhv.Controls.Add(this.chktimtheolop);
            this.grtimkiemhv.Controls.Add(this.rdotenor);
            this.grtimkiemhv.Controls.Add(this.rdobaritone);
            this.grtimkiemhv.Controls.Add(this.rdobass);
            this.grtimkiemhv.Controls.Add(this.rdosoprano);
            this.grtimkiemhv.Controls.Add(this.rdocap3);
            this.grtimkiemhv.Controls.Add(this.rdocap2);
            this.grtimkiemhv.Controls.Add(this.rdocap1);
            this.grtimkiemhv.Controls.Add(this.txttenhocvien);
            this.grtimkiemhv.Controls.Add(this.txtmahocvien);
            this.grtimkiemhv.Controls.Add(this.chktimtheoloaigiong);
            this.grtimkiemhv.Controls.Add(this.chktimtheocapdo);
            this.grtimkiemhv.Controls.Add(this.chktimtenhocvien);
            this.grtimkiemhv.Controls.Add(this.chktimmahocvien);
            this.grtimkiemhv.Location = new System.Drawing.Point(12, 12);
            this.grtimkiemhv.Name = "grtimkiemhv";
            this.grtimkiemhv.Size = new System.Drawing.Size(357, 663);
            this.grtimkiemhv.TabIndex = 0;
            this.grtimkiemhv.TabStop = false;
            this.grtimkiemhv.Text = "Tìm kiếm học viên";
            // 
            // cbomonhoc
            // 
            this.cbomonhoc.FormattingEnabled = true;
            this.cbomonhoc.Location = new System.Drawing.Point(166, 453);
            this.cbomonhoc.Name = "cbomonhoc";
            this.cbomonhoc.Size = new System.Drawing.Size(173, 28);
            this.cbomonhoc.TabIndex = 23;
            // 
            // btnlamlai
            // 
            this.btnlamlai.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnlamlai.Location = new System.Drawing.Point(233, 517);
            this.btnlamlai.Name = "btnlamlai";
            this.btnlamlai.Size = new System.Drawing.Size(106, 41);
            this.btnlamlai.TabIndex = 22;
            this.btnlamlai.Text = "Đặt lại";
            this.btnlamlai.UseVisualStyleBackColor = false;
            this.btnlamlai.Click += new System.EventHandler(this.btnlamlai_Click);
            // 
            // btntimkiem
            // 
            this.btntimkiem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btntimkiem.Location = new System.Drawing.Point(91, 517);
            this.btntimkiem.Name = "btntimkiem";
            this.btntimkiem.Size = new System.Drawing.Size(106, 41);
            this.btntimkiem.TabIndex = 21;
            this.btntimkiem.Text = "Tìm kiếm";
            this.btntimkiem.UseVisualStyleBackColor = false;
            this.btntimkiem.Click += new System.EventHandler(this.btntimkiem_Click);
            // 
            // lbngaybd
            // 
            this.lbngaybd.AutoSize = true;
            this.lbngaybd.Location = new System.Drawing.Point(19, 462);
            this.lbngaybd.Name = "lbngaybd";
            this.lbngaybd.Size = new System.Drawing.Size(70, 20);
            this.lbngaybd.TabIndex = 19;
            this.lbngaybd.Text = "Môn học";
            // 
            // lbten
            // 
            this.lbten.AutoSize = true;
            this.lbten.Location = new System.Drawing.Point(20, 160);
            this.lbten.Name = "lbten";
            this.lbten.Size = new System.Drawing.Size(98, 20);
            this.lbten.TabIndex = 18;
            this.lbten.Text = "Tên học viên";
            // 
            // lbma
            // 
            this.lbma.AutoSize = true;
            this.lbma.Location = new System.Drawing.Point(20, 78);
            this.lbma.Name = "lbma";
            this.lbma.Size = new System.Drawing.Size(93, 20);
            this.lbma.TabIndex = 17;
            this.lbma.Text = "Mã học viên";
            // 
            // rdoalto
            // 
            this.rdoalto.AutoSize = true;
            this.rdoalto.Location = new System.Drawing.Point(24, 341);
            this.rdoalto.Name = "rdoalto";
            this.rdoalto.Size = new System.Drawing.Size(62, 24);
            this.rdoalto.TabIndex = 14;
            this.rdoalto.TabStop = true;
            this.rdoalto.Text = "Alto";
            this.rdoalto.UseVisualStyleBackColor = true;
            // 
            // chktimtheolop
            // 
            this.chktimtheolop.AutoSize = true;
            this.chktimtheolop.Location = new System.Drawing.Point(6, 413);
            this.chktimtheolop.Name = "chktimtheolop";
            this.chktimtheolop.Size = new System.Drawing.Size(136, 24);
            this.chktimtheolop.TabIndex = 4;
            this.chktimtheolop.Text = "Theo môn học";
            this.chktimtheolop.UseVisualStyleBackColor = true;
            this.chktimtheolop.Click += new System.EventHandler(this.chktimtheolop_Click);
            // 
            // rdotenor
            // 
            this.rdotenor.AutoSize = true;
            this.rdotenor.Location = new System.Drawing.Point(24, 371);
            this.rdotenor.Name = "rdotenor";
            this.rdotenor.Size = new System.Drawing.Size(75, 24);
            this.rdotenor.TabIndex = 12;
            this.rdotenor.TabStop = true;
            this.rdotenor.Text = "Tenor";
            this.rdotenor.UseVisualStyleBackColor = true;
            // 
            // rdobaritone
            // 
            this.rdobaritone.AutoSize = true;
            this.rdobaritone.Location = new System.Drawing.Point(177, 311);
            this.rdobaritone.Name = "rdobaritone";
            this.rdobaritone.Size = new System.Drawing.Size(94, 24);
            this.rdobaritone.TabIndex = 13;
            this.rdobaritone.TabStop = true;
            this.rdobaritone.Text = "Baritone";
            this.rdobaritone.UseVisualStyleBackColor = true;
            // 
            // rdobass
            // 
            this.rdobass.AutoSize = true;
            this.rdobass.Location = new System.Drawing.Point(177, 341);
            this.rdobass.Name = "rdobass";
            this.rdobass.Size = new System.Drawing.Size(70, 24);
            this.rdobass.TabIndex = 11;
            this.rdobass.TabStop = true;
            this.rdobass.Text = "Bass";
            this.rdobass.UseVisualStyleBackColor = true;
            // 
            // rdosoprano
            // 
            this.rdosoprano.AutoSize = true;
            this.rdosoprano.Location = new System.Drawing.Point(24, 311);
            this.rdosoprano.Name = "rdosoprano";
            this.rdosoprano.Size = new System.Drawing.Size(95, 24);
            this.rdosoprano.TabIndex = 10;
            this.rdosoprano.TabStop = true;
            this.rdosoprano.Text = "Soprano";
            this.rdosoprano.UseVisualStyleBackColor = true;
            // 
            // rdocap3
            // 
            this.rdocap3.AutoSize = true;
            this.rdocap3.Location = new System.Drawing.Point(276, 228);
            this.rdocap3.Name = "rdocap3";
            this.rdocap3.Size = new System.Drawing.Size(43, 24);
            this.rdocap3.TabIndex = 9;
            this.rdocap3.TabStop = true;
            this.rdocap3.Text = "3";
            this.rdocap3.UseVisualStyleBackColor = true;
            // 
            // rdocap2
            // 
            this.rdocap2.AutoSize = true;
            this.rdocap2.Location = new System.Drawing.Point(154, 228);
            this.rdocap2.Name = "rdocap2";
            this.rdocap2.Size = new System.Drawing.Size(43, 24);
            this.rdocap2.TabIndex = 8;
            this.rdocap2.TabStop = true;
            this.rdocap2.Text = "2";
            this.rdocap2.UseVisualStyleBackColor = true;
            // 
            // rdocap1
            // 
            this.rdocap1.AutoSize = true;
            this.rdocap1.Location = new System.Drawing.Point(24, 228);
            this.rdocap1.Name = "rdocap1";
            this.rdocap1.Size = new System.Drawing.Size(43, 24);
            this.rdocap1.TabIndex = 7;
            this.rdocap1.TabStop = true;
            this.rdocap1.Text = "1";
            this.rdocap1.UseVisualStyleBackColor = true;
            // 
            // txttenhocvien
            // 
            this.txttenhocvien.Location = new System.Drawing.Point(166, 157);
            this.txttenhocvien.Name = "txttenhocvien";
            this.txttenhocvien.Size = new System.Drawing.Size(173, 26);
            this.txttenhocvien.TabIndex = 6;
            // 
            // txtmahocvien
            // 
            this.txtmahocvien.Location = new System.Drawing.Point(166, 72);
            this.txtmahocvien.Name = "txtmahocvien";
            this.txtmahocvien.Size = new System.Drawing.Size(173, 26);
            this.txtmahocvien.TabIndex = 5;
            // 
            // chktimtheoloaigiong
            // 
            this.chktimtheoloaigiong.AutoSize = true;
            this.chktimtheoloaigiong.Location = new System.Drawing.Point(7, 272);
            this.chktimtheoloaigiong.Name = "chktimtheoloaigiong";
            this.chktimtheoloaigiong.Size = new System.Drawing.Size(142, 24);
            this.chktimtheoloaigiong.TabIndex = 3;
            this.chktimtheoloaigiong.Text = "Theo loại giọng";
            this.chktimtheoloaigiong.UseVisualStyleBackColor = true;
            this.chktimtheoloaigiong.Click += new System.EventHandler(this.chktimtheoloaigiong_Click);
            // 
            // chktimtheocapdo
            // 
            this.chktimtheocapdo.AutoSize = true;
            this.chktimtheocapdo.Location = new System.Drawing.Point(7, 201);
            this.chktimtheocapdo.Name = "chktimtheocapdo";
            this.chktimtheocapdo.Size = new System.Drawing.Size(123, 24);
            this.chktimtheocapdo.TabIndex = 2;
            this.chktimtheocapdo.Text = "Theo cấp độ";
            this.chktimtheocapdo.UseVisualStyleBackColor = true;
            this.chktimtheocapdo.Click += new System.EventHandler(this.chktimtheocapdo_Click);
            // 
            // chktimtenhocvien
            // 
            this.chktimtenhocvien.AutoSize = true;
            this.chktimtenhocvien.Location = new System.Drawing.Point(7, 115);
            this.chktimtenhocvien.Name = "chktimtenhocvien";
            this.chktimtenhocvien.Size = new System.Drawing.Size(160, 24);
            this.chktimtenhocvien.TabIndex = 1;
            this.chktimtenhocvien.Text = "Theo tên học viên";
            this.chktimtenhocvien.UseVisualStyleBackColor = true;
            this.chktimtenhocvien.Click += new System.EventHandler(this.chktimtenhocvien_Click);
            // 
            // chktimmahocvien
            // 
            this.chktimmahocvien.AutoSize = true;
            this.chktimmahocvien.Location = new System.Drawing.Point(7, 41);
            this.chktimmahocvien.Name = "chktimmahocvien";
            this.chktimmahocvien.Size = new System.Drawing.Size(159, 24);
            this.chktimmahocvien.TabIndex = 0;
            this.chktimmahocvien.Text = "Theo mã học viên";
            this.chktimmahocvien.UseVisualStyleBackColor = true;
            this.chktimmahocvien.Click += new System.EventHandler(this.chktimmahocvien_Click);
            // 
            // btnthem
            // 
            this.btnthem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnthem.Location = new System.Drawing.Point(31, 272);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(90, 35);
            this.btnthem.TabIndex = 1;
            this.btnthem.Text = "Thêm";
            this.btnthem.UseVisualStyleBackColor = false;
            this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnxoa.Location = new System.Drawing.Point(242, 272);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(90, 35);
            this.btnxoa.TabIndex = 2;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.UseVisualStyleBackColor = false;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btnsua
            // 
            this.btnsua.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnsua.Location = new System.Drawing.Point(440, 272);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(90, 35);
            this.btnsua.TabIndex = 3;
            this.btnsua.Text = "Sửa";
            this.btnsua.UseVisualStyleBackColor = false;
            this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
            // 
            // dataGridViewhocvien
            // 
            this.dataGridViewhocvien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewhocvien.Location = new System.Drawing.Point(396, 363);
            this.dataGridViewhocvien.Name = "dataGridViewhocvien";
            this.dataGridViewhocvien.RowHeadersWidth = 62;
            this.dataGridViewhocvien.RowTemplate.Height = 28;
            this.dataGridViewhocvien.Size = new System.Drawing.Size(901, 265);
            this.dataGridViewhocvien.TabIndex = 4;
            this.dataGridViewhocvien.Click += new System.EventHandler(this.dataGridViewhocvien_Click);
            // 
            // btnxemall
            // 
            this.btnxemall.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnxemall.Location = new System.Drawing.Point(1130, 634);
            this.btnxemall.Name = "btnxemall";
            this.btnxemall.Size = new System.Drawing.Size(167, 41);
            this.btnxemall.TabIndex = 5;
            this.btnxemall.Text = "Xem tất cả";
            this.btnxemall.UseVisualStyleBackColor = false;
            this.btnxemall.Click += new System.EventHandler(this.btnxemall_Click);
            // 
            // grdieuchinhhv
            // 
            this.grdieuchinhhv.Controls.Add(this.txtdiachi);
            this.grdieuchinhhv.Controls.Add(this.label10);
            this.grdieuchinhhv.Controls.Add(this.mskngaysinh);
            this.grdieuchinhhv.Controls.Add(this.label9);
            this.grdieuchinhhv.Controls.Add(this.msksdt);
            this.grdieuchinhhv.Controls.Add(this.txtemail);
            this.grdieuchinhhv.Controls.Add(this.label8);
            this.grdieuchinhhv.Controls.Add(this.label7);
            this.grdieuchinhhv.Controls.Add(this.cbothongtincapdo);
            this.grdieuchinhhv.Controls.Add(this.cbothongtinloaigiong);
            this.grdieuchinhhv.Controls.Add(this.btnboqua);
            this.grdieuchinhhv.Controls.Add(this.btnluu);
            this.grdieuchinhhv.Controls.Add(this.chkgtnu);
            this.grdieuchinhhv.Controls.Add(this.chkgtnam);
            this.grdieuchinhhv.Controls.Add(this.txtthongtintenhv);
            this.grdieuchinhhv.Controls.Add(this.txtthongtinmahv);
            this.grdieuchinhhv.Controls.Add(this.label6);
            this.grdieuchinhhv.Controls.Add(this.label5);
            this.grdieuchinhhv.Controls.Add(this.label4);
            this.grdieuchinhhv.Controls.Add(this.label3);
            this.grdieuchinhhv.Controls.Add(this.label2);
            this.grdieuchinhhv.Controls.Add(this.label1);
            this.grdieuchinhhv.Controls.Add(this.btnthem);
            this.grdieuchinhhv.Controls.Add(this.btnxoa);
            this.grdieuchinhhv.Controls.Add(this.btnsua);
            this.grdieuchinhhv.Location = new System.Drawing.Point(396, 12);
            this.grdieuchinhhv.Name = "grdieuchinhhv";
            this.grdieuchinhhv.Size = new System.Drawing.Size(901, 335);
            this.grdieuchinhhv.TabIndex = 6;
            this.grdieuchinhhv.TabStop = false;
            this.grdieuchinhhv.Text = "Thông tin học viên";
            // 
            // txtdiachi
            // 
            this.txtdiachi.Location = new System.Drawing.Point(138, 228);
            this.txtdiachi.Name = "txtdiachi";
            this.txtdiachi.Size = new System.Drawing.Size(741, 26);
            this.txtdiachi.TabIndex = 30;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 228);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 20);
            this.label10.TabIndex = 29;
            this.label10.Text = "Địa chỉ";
            // 
            // mskngaysinh
            // 
            this.mskngaysinh.Location = new System.Drawing.Point(415, 89);
            this.mskngaysinh.Mask = "00/00/0000";
            this.mskngaysinh.Name = "mskngaysinh";
            this.mskngaysinh.Size = new System.Drawing.Size(169, 26);
            this.mskngaysinh.TabIndex = 28;
            this.mskngaysinh.ValidatingType = typeof(System.DateTime);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(331, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 20);
            this.label9.TabIndex = 27;
            this.label9.Text = "Ngày sinh";
            // 
            // msksdt
            // 
            this.msksdt.Location = new System.Drawing.Point(713, 89);
            this.msksdt.Mask = "(999) 000-0000";
            this.msksdt.Name = "msksdt";
            this.msksdt.Size = new System.Drawing.Size(168, 26);
            this.msksdt.TabIndex = 26;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(138, 185);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(743, 26);
            this.txtemail.TabIndex = 25;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(620, 89);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 20);
            this.label8.TabIndex = 24;
            this.label8.Text = "SĐT";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 185);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 20);
            this.label7.TabIndex = 23;
            this.label7.Text = "Email";
            // 
            // cbothongtincapdo
            // 
            this.cbothongtincapdo.FormattingEnabled = true;
            this.cbothongtincapdo.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.cbothongtincapdo.Location = new System.Drawing.Point(138, 132);
            this.cbothongtincapdo.Name = "cbothongtincapdo";
            this.cbothongtincapdo.Size = new System.Drawing.Size(168, 28);
            this.cbothongtincapdo.TabIndex = 22;
            // 
            // cbothongtinloaigiong
            // 
            this.cbothongtinloaigiong.FormattingEnabled = true;
            this.cbothongtinloaigiong.Items.AddRange(new object[] {
            "Soprano",
            "Alto",
            "Tenor",
            "Baritone",
            "Bass"});
            this.cbothongtinloaigiong.Location = new System.Drawing.Point(416, 140);
            this.cbothongtinloaigiong.Name = "cbothongtinloaigiong";
            this.cbothongtinloaigiong.Size = new System.Drawing.Size(168, 28);
            this.cbothongtinloaigiong.TabIndex = 20;
            // 
            // btnboqua
            // 
            this.btnboqua.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnboqua.Location = new System.Drawing.Point(791, 272);
            this.btnboqua.Name = "btnboqua";
            this.btnboqua.Size = new System.Drawing.Size(90, 35);
            this.btnboqua.TabIndex = 19;
            this.btnboqua.Text = "Bỏ qua";
            this.btnboqua.UseVisualStyleBackColor = false;
            this.btnboqua.Click += new System.EventHandler(this.btnboqua_Click);
            // 
            // btnluu
            // 
            this.btnluu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnluu.Location = new System.Drawing.Point(624, 272);
            this.btnluu.Name = "btnluu";
            this.btnluu.Size = new System.Drawing.Size(90, 35);
            this.btnluu.TabIndex = 18;
            this.btnluu.Text = "Lưu";
            this.btnluu.UseVisualStyleBackColor = false;
            this.btnluu.Click += new System.EventHandler(this.btnluu_Click);
            // 
            // chkgtnu
            // 
            this.chkgtnu.AutoSize = true;
            this.chkgtnu.Location = new System.Drawing.Point(516, 40);
            this.chkgtnu.Name = "chkgtnu";
            this.chkgtnu.Size = new System.Drawing.Size(55, 24);
            this.chkgtnu.TabIndex = 17;
            this.chkgtnu.Text = "Nữ";
            this.chkgtnu.UseVisualStyleBackColor = true;
            // 
            // chkgtnam
            // 
            this.chkgtnam.AutoSize = true;
            this.chkgtnam.Location = new System.Drawing.Point(416, 40);
            this.chkgtnam.Name = "chkgtnam";
            this.chkgtnam.Size = new System.Drawing.Size(68, 24);
            this.chkgtnam.TabIndex = 16;
            this.chkgtnam.Text = "Nam";
            this.chkgtnam.UseVisualStyleBackColor = true;
            // 
            // txtthongtintenhv
            // 
            this.txtthongtintenhv.Location = new System.Drawing.Point(138, 89);
            this.txtthongtintenhv.Name = "txtthongtintenhv";
            this.txtthongtintenhv.Size = new System.Drawing.Size(168, 26);
            this.txtthongtintenhv.TabIndex = 11;
            // 
            // txtthongtinmahv
            // 
            this.txtthongtinmahv.Location = new System.Drawing.Point(138, 39);
            this.txtthongtinmahv.Name = "txtthongtinmahv";
            this.txtthongtinmahv.Size = new System.Drawing.Size(168, 26);
            this.txtthongtinmahv.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(327, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Loại giọng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Cấp độ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(620, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 20);
            this.label4.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(331, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Giới tính";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tên học viên";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Mã học viên";
            // 
            // hocvien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1335, 687);
            this.Controls.Add(this.grdieuchinhhv);
            this.Controls.Add(this.btnxemall);
            this.Controls.Add(this.dataGridViewhocvien);
            this.Controls.Add(this.grtimkiemhv);
            this.MaximumSize = new System.Drawing.Size(1357, 743);
            this.Name = "hocvien";
            this.Text = "Quản lý học viên";
            this.Load += new System.EventHandler(this.hocvien_Load);
            this.grtimkiemhv.ResumeLayout(false);
            this.grtimkiemhv.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewhocvien)).EndInit();
            this.grdieuchinhhv.ResumeLayout(false);
            this.grdieuchinhhv.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grtimkiemhv;
        private System.Windows.Forms.CheckBox chktimtheocapdo;
        private System.Windows.Forms.CheckBox chktimtenhocvien;
        private System.Windows.Forms.CheckBox chktimmahocvien;
        private System.Windows.Forms.RadioButton rdocap3;
        private System.Windows.Forms.RadioButton rdocap2;
        private System.Windows.Forms.RadioButton rdocap1;
        private System.Windows.Forms.TextBox txttenhocvien;
        private System.Windows.Forms.TextBox txtmahocvien;
        private System.Windows.Forms.CheckBox chktimtheolop;
        private System.Windows.Forms.CheckBox chktimtheoloaigiong;
        private System.Windows.Forms.RadioButton rdoalto;
        private System.Windows.Forms.RadioButton rdotenor;
        private System.Windows.Forms.RadioButton rdobaritone;
        private System.Windows.Forms.RadioButton rdobass;
        private System.Windows.Forms.RadioButton rdosoprano;
        private System.Windows.Forms.Label lbngaybd;
        private System.Windows.Forms.Label lbten;
        private System.Windows.Forms.Label lbma;
        private System.Windows.Forms.Button btnlamlai;
        private System.Windows.Forms.Button btntimkiem;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.DataGridView dataGridViewhocvien;
        private System.Windows.Forms.Button btnxemall;
        private System.Windows.Forms.ComboBox cbomonhoc;
        private System.Windows.Forms.GroupBox grdieuchinhhv;
        private System.Windows.Forms.TextBox txtthongtintenhv;
        private System.Windows.Forms.TextBox txtthongtinmahv;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkgtnu;
        private System.Windows.Forms.CheckBox chkgtnam;
        private System.Windows.Forms.Button btnboqua;
        private System.Windows.Forms.Button btnluu;
        private System.Windows.Forms.ComboBox cbothongtinloaigiong;
        private System.Windows.Forms.ComboBox cbothongtincapdo;
        private System.Windows.Forms.MaskedTextBox msksdt;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtdiachi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.MaskedTextBox mskngaysinh;
        private System.Windows.Forms.Label label9;
    }
}

