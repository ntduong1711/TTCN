﻿namespace ttcn
{
    partial class kyhoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewky = new System.Windows.Forms.DataGridView();
            this.grtimkiemlop = new System.Windows.Forms.GroupBox();
            this.lbnam = new System.Windows.Forms.Label();
            this.txtnam = new System.Windows.Forms.TextBox();
            this.btnlamlai = new System.Windows.Forms.Button();
            this.btntimkiem = new System.Windows.Forms.Button();
            this.lbten = new System.Windows.Forms.Label();
            this.lbma = new System.Windows.Forms.Label();
            this.txttenky = new System.Windows.Forms.TextBox();
            this.txtmaky = new System.Windows.Forms.TextBox();
            this.chktimtheonam = new System.Windows.Forms.CheckBox();
            this.chktimtenky = new System.Windows.Forms.CheckBox();
            this.chktimmaky = new System.Windows.Forms.CheckBox();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btnthem = new System.Windows.Forms.Button();
            this.btnxemall = new System.Windows.Forms.Button();
            this.grthongtinky = new System.Windows.Forms.GroupBox();
            this.btnboqua = new System.Windows.Forms.Button();
            this.btnluu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtthongtinmaky = new System.Windows.Forms.TextBox();
            this.txtthongtintenky = new System.Windows.Forms.TextBox();
            this.txtthongtinnam = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewky)).BeginInit();
            this.grtimkiemlop.SuspendLayout();
            this.grthongtinky.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewky
            // 
            this.dataGridViewky.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewky.Location = new System.Drawing.Point(398, 335);
            this.dataGridViewky.Name = "dataGridViewky";
            this.dataGridViewky.RowHeadersWidth = 62;
            this.dataGridViewky.RowTemplate.Height = 28;
            this.dataGridViewky.Size = new System.Drawing.Size(778, 322);
            this.dataGridViewky.TabIndex = 8;
            this.dataGridViewky.Click += new System.EventHandler(this.dataGridViewky_Click);
            // 
            // grtimkiemlop
            // 
            this.grtimkiemlop.Controls.Add(this.lbnam);
            this.grtimkiemlop.Controls.Add(this.txtnam);
            this.grtimkiemlop.Controls.Add(this.btnlamlai);
            this.grtimkiemlop.Controls.Add(this.btntimkiem);
            this.grtimkiemlop.Controls.Add(this.lbten);
            this.grtimkiemlop.Controls.Add(this.lbma);
            this.grtimkiemlop.Controls.Add(this.txttenky);
            this.grtimkiemlop.Controls.Add(this.txtmaky);
            this.grtimkiemlop.Controls.Add(this.chktimtheonam);
            this.grtimkiemlop.Controls.Add(this.chktimtenky);
            this.grtimkiemlop.Controls.Add(this.chktimmaky);
            this.grtimkiemlop.Location = new System.Drawing.Point(12, 22);
            this.grtimkiemlop.Name = "grtimkiemlop";
            this.grtimkiemlop.Size = new System.Drawing.Size(357, 682);
            this.grtimkiemlop.TabIndex = 7;
            this.grtimkiemlop.TabStop = false;
            this.grtimkiemlop.Text = "Tìm kiếm lớp học";
            // 
            // lbnam
            // 
            this.lbnam.AutoSize = true;
            this.lbnam.Location = new System.Drawing.Point(19, 244);
            this.lbnam.Name = "lbnam";
            this.lbnam.Size = new System.Drawing.Size(72, 20);
            this.lbnam.TabIndex = 24;
            this.lbnam.Text = "Năm học";
            // 
            // txtnam
            // 
            this.txtnam.Location = new System.Drawing.Point(165, 238);
            this.txtnam.Name = "txtnam";
            this.txtnam.Size = new System.Drawing.Size(173, 26);
            this.txtnam.TabIndex = 23;
            // 
            // btnlamlai
            // 
            this.btnlamlai.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnlamlai.Location = new System.Drawing.Point(232, 500);
            this.btnlamlai.Name = "btnlamlai";
            this.btnlamlai.Size = new System.Drawing.Size(106, 41);
            this.btnlamlai.TabIndex = 22;
            this.btnlamlai.Text = "Đặt lại";
            this.btnlamlai.UseVisualStyleBackColor = false;
            this.btnlamlai.Click += new System.EventHandler(this.btnlamlai_Click);
            // 
            // btntimkiem
            // 
            this.btntimkiem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btntimkiem.Location = new System.Drawing.Point(91, 500);
            this.btntimkiem.Name = "btntimkiem";
            this.btntimkiem.Size = new System.Drawing.Size(106, 41);
            this.btntimkiem.TabIndex = 21;
            this.btntimkiem.Text = "Tìm kiếm";
            this.btntimkiem.UseVisualStyleBackColor = false;
            this.btntimkiem.Click += new System.EventHandler(this.btntimkiem_Click_1);
            // 
            // lbten
            // 
            this.lbten.AutoSize = true;
            this.lbten.Location = new System.Drawing.Point(20, 160);
            this.lbten.Name = "lbten";
            this.lbten.Size = new System.Drawing.Size(55, 20);
            this.lbten.TabIndex = 18;
            this.lbten.Text = "Tên kỳ";
            // 
            // lbma
            // 
            this.lbma.AutoSize = true;
            this.lbma.Location = new System.Drawing.Point(20, 78);
            this.lbma.Name = "lbma";
            this.lbma.Size = new System.Drawing.Size(80, 20);
            this.lbma.TabIndex = 17;
            this.lbma.Text = "Mã kỳ học";
            // 
            // txttenky
            // 
            this.txttenky.Location = new System.Drawing.Point(166, 157);
            this.txttenky.Name = "txttenky";
            this.txttenky.Size = new System.Drawing.Size(173, 26);
            this.txttenky.TabIndex = 6;
            // 
            // txtmaky
            // 
            this.txtmaky.Location = new System.Drawing.Point(166, 72);
            this.txtmaky.Name = "txtmaky";
            this.txtmaky.Size = new System.Drawing.Size(173, 26);
            this.txtmaky.TabIndex = 5;
            // 
            // chktimtheonam
            // 
            this.chktimtheonam.AutoSize = true;
            this.chktimtheonam.Location = new System.Drawing.Point(6, 202);
            this.chktimtheonam.Name = "chktimtheonam";
            this.chktimtheonam.Size = new System.Drawing.Size(110, 24);
            this.chktimtheonam.TabIndex = 3;
            this.chktimtheonam.Text = "Theo năm ";
            this.chktimtheonam.UseVisualStyleBackColor = true;
            // 
            // chktimtenky
            // 
            this.chktimtenky.AutoSize = true;
            this.chktimtenky.Location = new System.Drawing.Point(7, 115);
            this.chktimtenky.Name = "chktimtenky";
            this.chktimtenky.Size = new System.Drawing.Size(117, 24);
            this.chktimtenky.TabIndex = 1;
            this.chktimtenky.Text = "Theo tên kỳ";
            this.chktimtenky.UseVisualStyleBackColor = true;
            // 
            // chktimmaky
            // 
            this.chktimmaky.AutoSize = true;
            this.chktimmaky.Location = new System.Drawing.Point(7, 41);
            this.chktimmaky.Name = "chktimmaky";
            this.chktimmaky.Size = new System.Drawing.Size(116, 24);
            this.chktimmaky.TabIndex = 0;
            this.chktimmaky.Text = "Theo mã kỳ";
            this.chktimmaky.UseVisualStyleBackColor = true;
            // 
            // btnsua
            // 
            this.btnsua.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnsua.Location = new System.Drawing.Point(360, 238);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(90, 35);
            this.btnsua.TabIndex = 12;
            this.btnsua.Text = "Sửa";
            this.btnsua.UseVisualStyleBackColor = false;
            // 
            // btnxoa
            // 
            this.btnxoa.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnxoa.Location = new System.Drawing.Point(192, 238);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(90, 35);
            this.btnxoa.TabIndex = 11;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.UseVisualStyleBackColor = false;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btnthem
            // 
            this.btnthem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnthem.Location = new System.Drawing.Point(16, 238);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(90, 35);
            this.btnthem.TabIndex = 10;
            this.btnthem.Text = "Thêm";
            this.btnthem.UseVisualStyleBackColor = false;
            this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
            // 
            // btnxemall
            // 
            this.btnxemall.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnxemall.Location = new System.Drawing.Point(883, 663);
            this.btnxemall.Name = "btnxemall";
            this.btnxemall.Size = new System.Drawing.Size(167, 41);
            this.btnxemall.TabIndex = 13;
            this.btnxemall.Text = "Xem tất cả";
            this.btnxemall.UseVisualStyleBackColor = false;
            // 
            // grthongtinky
            // 
            this.grthongtinky.Controls.Add(this.txtthongtinnam);
            this.grthongtinky.Controls.Add(this.txtthongtintenky);
            this.grthongtinky.Controls.Add(this.txtthongtinmaky);
            this.grthongtinky.Controls.Add(this.label3);
            this.grthongtinky.Controls.Add(this.label2);
            this.grthongtinky.Controls.Add(this.label1);
            this.grthongtinky.Controls.Add(this.btnluu);
            this.grthongtinky.Controls.Add(this.btnboqua);
            this.grthongtinky.Controls.Add(this.btnthem);
            this.grthongtinky.Controls.Add(this.btnsua);
            this.grthongtinky.Controls.Add(this.btnxoa);
            this.grthongtinky.Location = new System.Drawing.Point(398, 22);
            this.grthongtinky.Name = "grthongtinky";
            this.grthongtinky.Size = new System.Drawing.Size(778, 291);
            this.grthongtinky.TabIndex = 14;
            this.grthongtinky.TabStop = false;
            this.grthongtinky.Text = "Thông tin kỳ học";
            // 
            // btnboqua
            // 
            this.btnboqua.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnboqua.Location = new System.Drawing.Point(515, 238);
            this.btnboqua.Name = "btnboqua";
            this.btnboqua.Size = new System.Drawing.Size(90, 35);
            this.btnboqua.TabIndex = 13;
            this.btnboqua.Text = "Bỏ qua";
            this.btnboqua.UseVisualStyleBackColor = false;
            this.btnboqua.Click += new System.EventHandler(this.btnboqua_Click);
            // 
            // btnluu
            // 
            this.btnluu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnluu.Location = new System.Drawing.Point(663, 238);
            this.btnluu.Name = "btnluu";
            this.btnluu.Size = new System.Drawing.Size(90, 35);
            this.btnluu.TabIndex = 14;
            this.btnluu.Text = "Lưu";
            this.btnluu.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(154, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 25;
            this.label1.Text = "Mã kỳ học";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(154, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 25;
            this.label2.Text = "Tên kỳ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(154, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 25;
            this.label3.Text = "Năm học";
            // 
            // txtthongtinmaky
            // 
            this.txtthongtinmaky.Location = new System.Drawing.Point(305, 38);
            this.txtthongtinmaky.Name = "txtthongtinmaky";
            this.txtthongtinmaky.Size = new System.Drawing.Size(217, 26);
            this.txtthongtinmaky.TabIndex = 26;
            // 
            // txtthongtintenky
            // 
            this.txtthongtintenky.Location = new System.Drawing.Point(305, 106);
            this.txtthongtintenky.Name = "txtthongtintenky";
            this.txtthongtintenky.Size = new System.Drawing.Size(217, 26);
            this.txtthongtintenky.TabIndex = 27;
            // 
            // txtthongtinnam
            // 
            this.txtthongtinnam.Location = new System.Drawing.Point(305, 176);
            this.txtthongtinnam.Name = "txtthongtinnam";
            this.txtthongtinnam.Size = new System.Drawing.Size(217, 26);
            this.txtthongtinnam.TabIndex = 28;
            // 
            // kyhoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 736);
            this.Controls.Add(this.btnxemall);
            this.Controls.Add(this.dataGridViewky);
            this.Controls.Add(this.grtimkiemlop);
            this.Controls.Add(this.grthongtinky);
            this.Name = "kyhoc";
            this.Text = "Quản lý kỳ học";
            this.Load += new System.EventHandler(this.kyhoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewky)).EndInit();
            this.grtimkiemlop.ResumeLayout(false);
            this.grtimkiemlop.PerformLayout();
            this.grthongtinky.ResumeLayout(false);
            this.grthongtinky.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewky;
        private System.Windows.Forms.GroupBox grtimkiemlop;
        private System.Windows.Forms.Label lbnam;
        private System.Windows.Forms.TextBox txtnam;
        private System.Windows.Forms.Button btnlamlai;
        private System.Windows.Forms.Button btntimkiem;
        private System.Windows.Forms.Label lbten;
        private System.Windows.Forms.Label lbma;
        private System.Windows.Forms.TextBox txttenky;
        private System.Windows.Forms.TextBox txtmaky;
        private System.Windows.Forms.CheckBox chktimtheonam;
        private System.Windows.Forms.CheckBox chktimtenky;
        private System.Windows.Forms.CheckBox chktimmaky;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.Button btnxemall;
        private System.Windows.Forms.GroupBox grthongtinky;
        private System.Windows.Forms.Button btnluu;
        private System.Windows.Forms.Button btnboqua;
        private System.Windows.Forms.TextBox txtthongtinnam;
        private System.Windows.Forms.TextBox txtthongtintenky;
        private System.Windows.Forms.TextBox txtthongtinmaky;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}