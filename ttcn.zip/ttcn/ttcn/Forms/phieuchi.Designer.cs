﻿namespace ttcn.Forms
{
    partial class phieuchi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btndatlai = new System.Windows.Forms.Button();
            this.btntim = new System.Windows.Forms.Button();
            this.cbotimkiemtrangthai = new System.Windows.Forms.ComboBox();
            this.cbotimkiemnguoinhan = new System.Windows.Forms.ComboBox();
            this.txttimkiemsukien = new System.Windows.Forms.TextBox();
            this.txttimkiemsophieu = new System.Windows.Forms.TextBox();
            this.chktheotrangthai = new System.Windows.Forms.CheckBox();
            this.chktheosukien = new System.Windows.Forms.CheckBox();
            this.chktheonguoinhan = new System.Windows.Forms.CheckBox();
            this.chktheosophieu = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnboqua = new System.Windows.Forms.Button();
            this.btnluu = new System.Windows.Forms.Button();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btnthem = new System.Windows.Forms.Button();
            this.cbothongtinsukien = new System.Windows.Forms.ComboBox();
            this.rdochuaduyet = new System.Windows.Forms.RadioButton();
            this.rdodaduyet = new System.Windows.Forms.RadioButton();
            this.txtthongtintongtien = new System.Windows.Forms.TextBox();
            this.cbothongtinnguoinhan = new System.Windows.Forms.ComboBox();
            this.txtthongtinsophieu = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewphieuchi = new System.Windows.Forms.DataGridView();
            this.btnxuatphieu = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewphieuchi)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btndatlai);
            this.groupBox1.Controls.Add(this.btntim);
            this.groupBox1.Controls.Add(this.cbotimkiemtrangthai);
            this.groupBox1.Controls.Add(this.cbotimkiemnguoinhan);
            this.groupBox1.Controls.Add(this.txttimkiemsukien);
            this.groupBox1.Controls.Add(this.txttimkiemsophieu);
            this.groupBox1.Controls.Add(this.chktheotrangthai);
            this.groupBox1.Controls.Add(this.chktheosukien);
            this.groupBox1.Controls.Add(this.chktheonguoinhan);
            this.groupBox1.Controls.Add(this.chktheosophieu);
            this.groupBox1.Location = new System.Drawing.Point(35, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(262, 626);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm ";
            // 
            // btndatlai
            // 
            this.btndatlai.Location = new System.Drawing.Point(165, 568);
            this.btndatlai.Name = "btndatlai";
            this.btndatlai.Size = new System.Drawing.Size(91, 41);
            this.btndatlai.TabIndex = 14;
            this.btndatlai.Text = "Đặt lại";
            this.btndatlai.UseVisualStyleBackColor = true;
            this.btndatlai.Click += new System.EventHandler(this.btndatlai_Click);
            // 
            // btntim
            // 
            this.btntim.Location = new System.Drawing.Point(6, 568);
            this.btntim.Name = "btntim";
            this.btntim.Size = new System.Drawing.Size(91, 41);
            this.btntim.TabIndex = 18;
            this.btntim.Text = "Tìm";
            this.btntim.UseVisualStyleBackColor = true;
            this.btntim.Click += new System.EventHandler(this.btntim_Click);
            // 
            // cbotimkiemtrangthai
            // 
            this.cbotimkiemtrangthai.FormattingEnabled = true;
            this.cbotimkiemtrangthai.Location = new System.Drawing.Point(16, 442);
            this.cbotimkiemtrangthai.Name = "cbotimkiemtrangthai";
            this.cbotimkiemtrangthai.Size = new System.Drawing.Size(203, 28);
            this.cbotimkiemtrangthai.TabIndex = 7;
            // 
            // cbotimkiemnguoinhan
            // 
            this.cbotimkiemnguoinhan.FormattingEnabled = true;
            this.cbotimkiemnguoinhan.Location = new System.Drawing.Point(16, 180);
            this.cbotimkiemnguoinhan.Name = "cbotimkiemnguoinhan";
            this.cbotimkiemnguoinhan.Size = new System.Drawing.Size(203, 28);
            this.cbotimkiemnguoinhan.TabIndex = 6;
            // 
            // txttimkiemsukien
            // 
            this.txttimkiemsukien.Location = new System.Drawing.Point(16, 299);
            this.txttimkiemsukien.Name = "txttimkiemsukien";
            this.txttimkiemsukien.Size = new System.Drawing.Size(203, 26);
            this.txttimkiemsukien.TabIndex = 5;
            // 
            // txttimkiemsophieu
            // 
            this.txttimkiemsophieu.Location = new System.Drawing.Point(16, 81);
            this.txttimkiemsophieu.Name = "txttimkiemsophieu";
            this.txttimkiemsophieu.Size = new System.Drawing.Size(203, 26);
            this.txttimkiemsophieu.TabIndex = 4;
            // 
            // chktheotrangthai
            // 
            this.chktheotrangthai.AutoSize = true;
            this.chktheotrangthai.Location = new System.Drawing.Point(16, 377);
            this.chktheotrangthai.Name = "chktheotrangthai";
            this.chktheotrangthai.Size = new System.Drawing.Size(142, 24);
            this.chktheotrangthai.TabIndex = 3;
            this.chktheotrangthai.Text = "Theo trạng thái";
            this.chktheotrangthai.UseVisualStyleBackColor = true;
            this.chktheotrangthai.Click += new System.EventHandler(this.chktheotrangthai_Click);
            // 
            // chktheosukien
            // 
            this.chktheosukien.AutoSize = true;
            this.chktheosukien.Location = new System.Drawing.Point(16, 250);
            this.chktheosukien.Name = "chktheosukien";
            this.chktheosukien.Size = new System.Drawing.Size(125, 24);
            this.chktheosukien.TabIndex = 2;
            this.chktheosukien.Text = "Theo sự kiện";
            this.chktheosukien.UseVisualStyleBackColor = true;
            this.chktheosukien.Click += new System.EventHandler(this.chktheosukien_Click);
            // 
            // chktheonguoinhan
            // 
            this.chktheonguoinhan.AutoSize = true;
            this.chktheonguoinhan.Location = new System.Drawing.Point(16, 135);
            this.chktheonguoinhan.Name = "chktheonguoinhan";
            this.chktheonguoinhan.Size = new System.Drawing.Size(154, 24);
            this.chktheonguoinhan.TabIndex = 1;
            this.chktheonguoinhan.Text = "Theo người nhận";
            this.chktheonguoinhan.UseVisualStyleBackColor = true;
            this.chktheonguoinhan.Click += new System.EventHandler(this.chktheonguoinhan_Click);
            // 
            // chktheosophieu
            // 
            this.chktheosophieu.AutoSize = true;
            this.chktheosophieu.Location = new System.Drawing.Point(16, 36);
            this.chktheosophieu.Name = "chktheosophieu";
            this.chktheosophieu.Size = new System.Drawing.Size(135, 24);
            this.chktheosophieu.TabIndex = 0;
            this.chktheosophieu.Text = "Theo số phiếu";
            this.chktheosophieu.UseVisualStyleBackColor = true;
            this.chktheosophieu.Click += new System.EventHandler(this.chktheosophieu_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnboqua);
            this.groupBox2.Controls.Add(this.btnluu);
            this.groupBox2.Controls.Add(this.btnsua);
            this.groupBox2.Controls.Add(this.btnxoa);
            this.groupBox2.Controls.Add(this.btnthem);
            this.groupBox2.Controls.Add(this.cbothongtinsukien);
            this.groupBox2.Controls.Add(this.rdochuaduyet);
            this.groupBox2.Controls.Add(this.rdodaduyet);
            this.groupBox2.Controls.Add(this.txtthongtintongtien);
            this.groupBox2.Controls.Add(this.cbothongtinnguoinhan);
            this.groupBox2.Controls.Add(this.txtthongtinsophieu);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(326, 26);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(842, 260);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Phiếu chi";
            // 
            // btnboqua
            // 
            this.btnboqua.Location = new System.Drawing.Point(704, 213);
            this.btnboqua.Name = "btnboqua";
            this.btnboqua.Size = new System.Drawing.Size(91, 41);
            this.btnboqua.TabIndex = 17;
            this.btnboqua.Text = "Bỏ qua";
            this.btnboqua.UseVisualStyleBackColor = true;
            this.btnboqua.Click += new System.EventHandler(this.btnboqua_Click);
            // 
            // btnluu
            // 
            this.btnluu.Location = new System.Drawing.Point(551, 213);
            this.btnluu.Name = "btnluu";
            this.btnluu.Size = new System.Drawing.Size(91, 41);
            this.btnluu.TabIndex = 16;
            this.btnluu.Text = "Lưu";
            this.btnluu.UseVisualStyleBackColor = true;
            this.btnluu.Click += new System.EventHandler(this.btnluu_Click);
            // 
            // btnsua
            // 
            this.btnsua.Location = new System.Drawing.Point(400, 213);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(91, 41);
            this.btnsua.TabIndex = 15;
            this.btnsua.Text = "Sửa";
            this.btnsua.UseVisualStyleBackColor = true;
            this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(233, 213);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(91, 41);
            this.btnxoa.TabIndex = 14;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.UseVisualStyleBackColor = true;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(67, 213);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(91, 41);
            this.btnthem.TabIndex = 13;
            this.btnthem.Text = "Thêm";
            this.btnthem.UseVisualStyleBackColor = true;
            this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
            // 
            // cbothongtinsukien
            // 
            this.cbothongtinsukien.FormattingEnabled = true;
            this.cbothongtinsukien.Location = new System.Drawing.Point(563, 98);
            this.cbothongtinsukien.Name = "cbothongtinsukien";
            this.cbothongtinsukien.Size = new System.Drawing.Size(203, 28);
            this.cbothongtinsukien.TabIndex = 12;
            // 
            // rdochuaduyet
            // 
            this.rdochuaduyet.AutoSize = true;
            this.rdochuaduyet.Location = new System.Drawing.Point(695, 29);
            this.rdochuaduyet.Name = "rdochuaduyet";
            this.rdochuaduyet.Size = new System.Drawing.Size(115, 24);
            this.rdochuaduyet.TabIndex = 11;
            this.rdochuaduyet.TabStop = true;
            this.rdochuaduyet.Text = "Chưa duyệt";
            this.rdochuaduyet.UseVisualStyleBackColor = true;
            // 
            // rdodaduyet
            // 
            this.rdodaduyet.AutoSize = true;
            this.rdodaduyet.Location = new System.Drawing.Point(563, 31);
            this.rdodaduyet.Name = "rdodaduyet";
            this.rdodaduyet.Size = new System.Drawing.Size(98, 24);
            this.rdodaduyet.TabIndex = 10;
            this.rdodaduyet.TabStop = true;
            this.rdodaduyet.Text = "Đã duyệt";
            this.rdodaduyet.UseVisualStyleBackColor = true;
            // 
            // txtthongtintongtien
            // 
            this.txtthongtintongtien.Location = new System.Drawing.Point(164, 163);
            this.txtthongtintongtien.Name = "txtthongtintongtien";
            this.txtthongtintongtien.Size = new System.Drawing.Size(203, 26);
            this.txtthongtintongtien.TabIndex = 9;
            // 
            // cbothongtinnguoinhan
            // 
            this.cbothongtinnguoinhan.FormattingEnabled = true;
            this.cbothongtinnguoinhan.Location = new System.Drawing.Point(164, 98);
            this.cbothongtinnguoinhan.Name = "cbothongtinnguoinhan";
            this.cbothongtinnguoinhan.Size = new System.Drawing.Size(203, 28);
            this.cbothongtinnguoinhan.TabIndex = 8;
            // 
            // txtthongtinsophieu
            // 
            this.txtthongtinsophieu.Location = new System.Drawing.Point(164, 30);
            this.txtthongtinsophieu.Name = "txtthongtinsophieu";
            this.txtthongtinsophieu.Size = new System.Drawing.Size(203, 26);
            this.txtthongtinsophieu.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Tổng tiền";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(396, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sự kiện";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(396, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Trạng thái xét duyệt";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Người nhận";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(63, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã số phiếu";
            // 
            // dataGridViewphieuchi
            // 
            this.dataGridViewphieuchi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewphieuchi.Location = new System.Drawing.Point(326, 325);
            this.dataGridViewphieuchi.Name = "dataGridViewphieuchi";
            this.dataGridViewphieuchi.RowHeadersWidth = 62;
            this.dataGridViewphieuchi.RowTemplate.Height = 28;
            this.dataGridViewphieuchi.Size = new System.Drawing.Size(842, 264);
            this.dataGridViewphieuchi.TabIndex = 2;
            this.dataGridViewphieuchi.Click += new System.EventHandler(this.dataGridViewphieuchi_Click);
            // 
            // btnxuatphieu
            // 
            this.btnxuatphieu.Location = new System.Drawing.Point(1063, 595);
            this.btnxuatphieu.Name = "btnxuatphieu";
            this.btnxuatphieu.Size = new System.Drawing.Size(104, 39);
            this.btnxuatphieu.TabIndex = 3;
            this.btnxuatphieu.Text = "In";
            this.btnxuatphieu.UseVisualStyleBackColor = true;
            // 
            // phieuchi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1210, 681);
            this.Controls.Add(this.btnxuatphieu);
            this.Controls.Add(this.dataGridViewphieuchi);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "phieuchi";
            this.Text = "Phiếu chi";
            this.Load += new System.EventHandler(this.phieuchi_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewphieuchi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chktheotrangthai;
        private System.Windows.Forms.CheckBox chktheosukien;
        private System.Windows.Forms.CheckBox chktheonguoinhan;
        private System.Windows.Forms.CheckBox chktheosophieu;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridViewphieuchi;
        private System.Windows.Forms.TextBox txttimkiemsukien;
        private System.Windows.Forms.TextBox txttimkiemsophieu;
        private System.Windows.Forms.ComboBox cbotimkiemtrangthai;
        private System.Windows.Forms.ComboBox cbotimkiemnguoinhan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdochuaduyet;
        private System.Windows.Forms.RadioButton rdodaduyet;
        private System.Windows.Forms.TextBox txtthongtintongtien;
        private System.Windows.Forms.ComboBox cbothongtinnguoinhan;
        private System.Windows.Forms.TextBox txtthongtinsophieu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbothongtinsukien;
        private System.Windows.Forms.Button btndatlai;
        private System.Windows.Forms.Button btntim;
        private System.Windows.Forms.Button btnboqua;
        private System.Windows.Forms.Button btnluu;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.Button btnxuatphieu;
    }
}